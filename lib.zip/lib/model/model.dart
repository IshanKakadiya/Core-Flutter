class Customer {
  String firstName;
  String lastName;
  String phoneNumber;
  String email;

  Customer({
    required this.firstName,
    required this.lastName,
    required this.phoneNumber,
    required this.email,
  });
}
